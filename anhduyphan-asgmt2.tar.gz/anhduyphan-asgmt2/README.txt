To Compile:
	type: gcc -g proj2.c -o proj2

To Run:
	type for First Come First Serve:        ./proj2 input.1 FCFS
	     for Preemptive Priority:           ./proj2 input.1 PP
	     for Round Robin:                   ./proj2 input.1 RR 2
